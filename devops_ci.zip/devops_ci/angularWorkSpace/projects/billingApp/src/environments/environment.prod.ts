export const environment = {
  production: true,
  basePath: 'http://localhost:7080'
};
